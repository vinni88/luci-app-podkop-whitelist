'use strict';
'require view';
'require form';
'require uci';
'require fs';
'require ui';
'require poll';

function parseState(raw) {
	var res = { mode: 'unknown', manual: '0', updated: '—', reason: '', probe: '' };
	if (!raw) return res;
	raw.split('\n').forEach(function(line) {
		var idx = line.indexOf('=');
		if (idx > 0) {
			res[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
		}
	});
	return res;
}

return view.extend({
	load: function() {
		return Promise.all([
			uci.load('podkop_whitelist'),
			uci.load('podkop'),
			L.resolveDefault(fs.read('/tmp/podkop_whitelist.state'), '')
		]);
	},

	render: function(data) {
		var state = parseState(data[2]);
		var podkopSections = uci.sections('podkop', 'section');

		var statusBadge = E('strong', { 'style': 'font-size: 1.05em;' }, '');
		var statusMeta = E('div', { 'style': 'margin-top: 4px; opacity: 0.8; font-size: 0.9em;' }, '');
		var statusProbe = E('div', { 'style': 'margin-top: 3px; opacity: 0.9; font-size: 0.9em; font-family: monospace;' }, '');
		var toggleBtn = E('button', {
			'class': 'btn cbi-button-action',
			'style': 'margin-top: 10px;'
		}, '');

		var sending = false;

		function updateStatusUI(st) {
			var isSwitching = (st.mode === 'switching');
			var isWl = (st.mode === 'whitelist');
			var isManual = (st.manual === '1');

			if (isSwitching) {
				statusBadge.textContent = 'ВЫПОЛНЯЕТСЯ ПЕРЕКЛЮЧЕНИЕ ПРАВИЛ...';
				statusBadge.style.color = '#f39c12';
			} else if (isWl && isManual) {
				statusBadge.textContent = 'АКТИВЕН РЕЖИМ ОБХОДА БС (Принудительно вручную)';
				statusBadge.style.color = '#e67e22';
			} else if (isWl) {
				statusBadge.textContent = 'АКТИВЕН РЕЖИМ ОБХОДА БС (Автоматически)';
				statusBadge.style.color = '#e67e22';
			} else {
				statusBadge.textContent = 'ОБЫЧНЫЙ РЕЖИМ РАБОТЫ';
				statusBadge.style.color = '#2ecc71';
			}

			statusMeta.textContent = 'Последнее обновление: ' + (st.updated || '—') +
				(st.reason ? ' | Событие: ' + st.reason : '');
			statusProbe.textContent = st.probe ? ('Проверка: ' + st.probe) : '';

			if (sending || isSwitching) {
				toggleBtn.disabled = true;
				toggleBtn.textContent = 'Переключение правил Podkop...';
			} else {
				toggleBtn.disabled = false;
				if (isManual) {
					toggleBtn.className = 'btn cbi-button-negative';
					toggleBtn.textContent = 'Выключить принудительный режим БС (вернуть обычный)';
				} else {
					toggleBtn.className = 'btn cbi-button-action';
					toggleBtn.textContent = 'Принудительно включить режим обхода БС';
				}
			}
		}

		updateStatusUI(state);

		toggleBtn.addEventListener('click', L.bind(function(ev) {
			ev.preventDefault();
			if (sending || state.mode === 'switching') return;
			sending = true;
			updateStatusUI(state);

			var action = (state.manual === '1') ? 'queue_manual_off' : 'queue_manual_on';
			fs.exec('/usr/bin/podkop-whitelist.sh', [action]).then(function() {
				sending = false;
				state.mode = 'switching';
				updateStatusUI(state);
			}).catch(function(err) {
				sending = false;
				updateStatusUI(state);
				ui.addNotification(null, E('p', 'Ошибка запуска переключения: ' + err.message), 'error');
			});
		}, this));

		poll.add(function() {
			return L.resolveDefault(fs.read('/tmp/podkop_whitelist.state'), '').then(function(raw) {
				if (raw) {
					state = parseState(raw);
					updateStatusUI(state);
				}
			});
		}, 2);

		var statusBox = E('div', { 'class': 'cbi-section', 'style': 'padding: 14px 16px;' }, [
			E('h3', { 'style': 'margin-top: 0;' }, 'Текущее состояние'),
			statusBadge,
			statusMeta,
			statusProbe,
			toggleBtn
		]);

		var m = new form.Map('podkop_whitelist', 'Podkop Whitelist — Автообход белых списков',
			'Переключает правила Podkop при блокировке зарубежного трафика (при доступности РФ-ресурсов) и заворачивает трафик подсети в резервное правило.');

		var s = m.section(form.NamedSection, 'settings', 'settings', 'Параметры переключения и проверки');
		s.anonymous = false;
		s.addremove = false;

		var o;

		o = s.option(form.Flag, 'enabled', 'Автоматический мониторинг (Watchdog)',
			'Следить за доступностью сети и автоматически переключать режимы.');
		o.default = '1';
		o.rmempty = false;

		var oNormal = s.option(form.MultiValue, 'normal_sections', 'Правила обычного режима',
			'Активны в штатном режиме и отключаются при срабатывании белых списков.');
		oNormal.widget = 'checkbox';
		oNormal.optional = true;

		var oWhitelist = s.option(form.MultiValue, 'whitelist_sections', 'Правила режима белых списков',
			'Включаются при срабатывании белых списков и отключаются при возврате в обычный режим.');
		oWhitelist.widget = 'checkbox';
		oWhitelist.optional = true;

		podkopSections.forEach(function(sec) {
			var id = sec['.name'];
			var label = sec.label ? (sec.label + ' (' + id + ')') : id;
			oNormal.value(id, label);
			oWhitelist.value(id, label);
		});

		o = s.option(form.Flag, 'all_traffic_enabled', 'Заворачивать весь трафик в правило БС',
			'Добавляет fully_routed_ips с указанными подсетями в правило БС только на время действия белых списков.');
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.DynamicList, 'all_traffic_ip', 'Подсети / IP для заворота всего трафика',
			'Список подсетей для опции fully_routed_ips (например, 192.168.1.0/24).');
		o.placeholder = '192.168.1.0/24';
		o.depends('all_traffic_enabled', '1');

		o = s.option(form.Value, 'check_url', 'URL проверки зарубежного трафика №1 (код 204)',
			'Основной HTTP-адрес для проверки отсутствия блокировок (должен возвращать код 204).');
		o.placeholder = 'http://connectivitycheck.gstatic.com/generate_204';
		o.default = 'http://connectivitycheck.gstatic.com/generate_204';
		o.optional = true;

		o = s.option(form.Value, 'check_url_2', 'URL проверки зарубежного трафика №2 (код 204)',
			'Резервный HTTP-адрес. Оставьте пустым, если нужна проверка только по одному адресу.');
		o.placeholder = 'http://cp.cloudflare.com/generate_204';
		o.optional = true;

		o = s.option(form.Value, 'whitelist_probe_url', 'Контрольный РФ-сайт для подтверждения БС',
			'Если зарубежные узлы молчат, но этот HTTP-адрес отвечает — подтверждается включение белых списков.');
		o.default = 'http://ya.ru';
		o.rmempty = false;

		o = s.option(form.Value, 'check_interval', 'Интервал проверки (сек.)');
		o.datatype = 'min(5)';
		o.default = '10';
		o.rmempty = false;

		o = s.option(form.Value, 'check_timeout', 'Таймаут запроса (сек.)');
		o.datatype = 'range(1,30)';
		o.default = '3';
		o.rmempty = false;

		o = s.option(form.Value, 'fail_count', 'Подтверждений БС подряд для переключения');
		o.datatype = 'min(1)';
		o.default = '2';
		o.rmempty = false;

		o = s.option(form.Value, 'recover_count', 'Успешных проверок подряд для возврата');
		o.datatype = 'min(1)';
		o.default = '2';
		o.rmempty = false;

		return m.render().then(function(formEl) {
			return E('div', {}, [statusBox, formEl]);
		});
	}
});
